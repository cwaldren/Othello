To compile:

gcc -O3 -std=c99 player.c
